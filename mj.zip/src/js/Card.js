const Card = [
  {
    serial: "01",
    Head: "Mint NFT",
    para: "You must own our NFT to connect to direct management or participate in governance",
  },
  {
    serial: "02",
    Head: "Verify NFT Ownership",
    para: "Only Cyber Drops that are have verified are eligible to be connected under direct management",
  },
  {
    serial: "03",
    Head: "Link API to your account",
    para: "Only HODLers that submit their API key and secret will be under direct management ",
  },
  {
    serial: "04",
    Head: "Passive Income for life",
    para: "As long as your HODL your Cyber Drop, you will be connected under direct management",
  },
];
export default Card;
