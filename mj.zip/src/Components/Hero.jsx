import React from "react";
import heroImg from "../assets/img/webp/hero-img.webp";
import Header from "./Header";

function Hero() {
  return (
    <section className="min_vh_100 d-flex flex-column">
      <div style={{ zIndex: "122" }}>
        <Header />
      </div>
      <div className="container d-flex align-items-center py-4">
        <div className="row align-items-center">
          <div className="col-md-7">
            <div className="">
              <h1 className="ff_lato fw_extrabold fs_7x2l text-white mb-0">
                Welcome to{" "}
                <span className="text_primary d-lg-block">Cyber Drops</span>
              </h1>
              <p className="ff_lato fw-normal fs_sm text-white mb-0 mt-sm-4 mt-2 pt-1 pb-md-3">
                Viverra felis, dui adipiscing ipsum pharetra donec. Pretium,
                tempus,{" "}
                <span className="d-lg-block">
                  enim tincidunt at nibh duis iaculis in mauris. Id elit nec
                  curabitur
                </span>{" "}
                purus. Ullamcorper mattis risus suspendisse pretium tristique.
              </p>

              <a
                class="ff_lato fw_medium fs_sm text-white z_index text_stroke mt-sm-5 mt-4 d-inline-block bottom_line primary_btn py-2 px-3"
                href="#about"
              >
                Explore Now
              </a>
            </div>
          </div>
          <div className="col-md-5 mt-sm-5 mt-4 mt-md-0">
            <div className="d-flex justify-content-center">
              <img className="Hero_img" src={heroImg} alt="img" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
