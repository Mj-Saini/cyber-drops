import React from "react";
import prasuet from "../assets/img/webp/prasuet.webp";

function WeDo() {
  return (
    <>
      <section className="py-4 py-lg-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-6">
              <div>
                <img className="w-100" src={prasuet} alt="img" />
              </div>
            </div>
            <div className="col-md-6">
              <div className="ps-lg-4">
                <h2 className="ff_lato fw-bold fs_4x8l text-white mb-0">
                  What <span className="text_primary">we do</span>
                </h2>
                <p className="ff_lato fw-normal fs_md text-white mb-0">
                  1000 Cyber Drops will be dropping on Ethereum in March{" "}
                  <span className="d-lg-block">
                    {" "}
                    2022. Each and every Cyber Drop is uniquely hand crafted.
                  </span>{" "}
                  This is just the beginning of our journey. Owning a Cyber Drop
                  will unlock monthly airdrops and future governance rights in
                  addition to our revolutionary algorithm. We strive to always
                  bring innovation and keep BUILDing. Cyber Drops is a community
                  driven project and always will be that way. That’s our
                  promise.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default WeDo;
