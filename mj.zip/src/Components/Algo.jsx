import React from "react";
import algo1 from "../assets/img/webp";

function Algo() {
  return (
    <>
      <section>
        <div className="container">
          <div className="row">
            <div className="col-6">
              <div className="ps-lg-4">
                <h2 className="ff_lato fw-bold fs_4x8l text-white mb-0">
                  Our <span className="text_primary"> Algo</span>
                </h2>
                <p className="ff_lato fw-normal fs_md text-white mb-0">
                  We have perfected our algorithm, which prioritizes a low risk
                  and consistent profit stream without the need for daily
                  micromanagement. While most trading algorithms can’t stand up
                  against a volatile or risky market, our algorithm thrives in
                  those conditions. Early-stage testers have seen a consistent
                  flow of income with minimal ups and downs. Our algorithm has
                  been in the works for YEARS. This has given us the time to
                  rigorously backtest and release any needed hotfixes. As of
                  early March 2022, we have close to a quarter of a million
                  under direct management!
                </p>
              </div>
            </div>
            <div className="col-6">
              <div className="row">
                <div className="col-5">
                  <img src={algo1} alt="algo-img" />
                </div>
                <div className="col-7">
                  <img src={algo1} alt="algo-img" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

export default Algo;
