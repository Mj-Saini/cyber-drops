import React from "react";
import playbit from "../assets/img/svg/playbit.svg";
import Number24 from "../assets/img/svg/number-24.svg";
import hive from "../assets/img/svg/hive.svg";
import focuss from "../assets/img/svg/focus.svg";

function Partners() {
  return (
    <>
      <section className="Partners_bg_img py-5 my-5">
        <div className="container pt-lg-5 pt-4">
          <h2 className=" ff_lato fw-bold fs_4x8l text_White text-center mb_custom">
            Part<span className=" text_primary">ners</span>
          </h2>
          <div class="LogoParant my-4 my-xl-0 ">
            <div class="slide_logo d-flex gap-5 px-3 align-items-center">
              <div className="d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={playbit} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center mx-auto">
                  Playbit
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={Number24} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  24 Capital
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={hive} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  TradingHive
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img
                  style={{ height: "95px" }}
                  className="w-100 w_xsm_50"
                  src={focuss}
                  alt="img-logo"
                />

                <h3 className="pt-4 ff_lato fw-bold fs_ms text-center">
                  Focus Group Equities
                </h3>
              </div>
            </div>

            <div class="slide_logo d-flex gap-5 align-items-center ms-auto">
              <div className=" d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={playbit} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  Playbit
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={Number24} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  24 Capital
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img className="w-100 w_xsm_50" src={hive} alt="img-logo" />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  TradingHive
                </h3>
              </div>

              <div className="d-flex flex-column align-items-center">
                <img
                  style={{ height: "95px" }}
                  className="w-100 w_xsm_50"
                  src={focuss}
                  alt="img-logo"
                />

                <h3 className="pt-4 ff_lato fs_ms fw-bold text-center">
                  Focus Group Equities
                </h3>
              </div>
            </div>
          </div>

          <p className="ff_lato fw-bold fs_md text_primary text-center mb-0 mt_custom">
            For business and collaborations, contact us team@cyberdrops.finance
          </p>
        </div>
      </section>
    </>
  );
}

export default Partners;
